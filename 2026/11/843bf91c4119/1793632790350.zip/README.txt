Three Lottie loading icons
512 x 512 | 30 fps | 2-second seamless loop | transparent background

Use the JSON files with a Lottie player. Set loop and autoplay to true.
The original logos are embedded as PNG assets; loading dots are vector shapes. No external image files required.
Loader 01 has black lettering and suits a light background. Loaders 02 and 03 have white lettering and suit dark backgrounds. GIFs are dark-background previews only.
The black background of the third source image was removed.
